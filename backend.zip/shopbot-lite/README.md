# ShopBot-lite backend

Minimal Node.js/Express backend built to pair with the Redtail frontend, for
a fast demo. Priorities, in order: **AI chat endpoint working**, then product
price-comparison. No auth, no Docker, no database — everything is in-memory.

## Run it

```
npm install
cp .env.example .env
# paste your Gemini key into GEMINI_API_KEY in .env
npm start
```

Server starts on `http://localhost:4000`. Works with **zero** env vars too —
if `GEMINI_API_KEY` is unset, chat falls back to a keyword heuristic instead
of erroring, so the demo never breaks.

## Endpoints

- `GET  /health` — sanity check, also reports whether Gemini/price provider are configured
- `POST /api/v1/chat/threads/:id/messages` — `{ "message": "find me wireless earbuds under $50" }`
  Any `:id` works (creates the thread on first use). Returns an assistant
  message; if the AI decides the user wants to shop, it also runs a price
  search and includes `offers` in the response.
- `GET  /api/v1/chat/threads/:id/messages` — full history for a thread
- `GET  /api/v1/products/search?query=wireless+earbuds` — price comparison directly, no chat involved
- `POST /api/v1/payments/init` — `{ "email": "buyer@example.com", "amount": 49.99, "offerId": "...", "quantity": 1 }`
  Starts a Paystack transaction server-side. Returns `authorizationUrl` (open in the Paystack webview/checkout) and `reference`.
- `POST /api/v1/payments/verify` — `{ "reference": "..." }`
  Re-checks the transaction directly with Paystack (never trusts the client). On success, creates an in-memory "order" you can extend into a real one.
- `POST /api/v1/payments/webhook` — point your Paystack dashboard's webhook URL here. HMAC-verified against `PAYSTACK_SECRET_KEY` before anything is trusted.
- `GET  /api/v1/payments/orders/:reference` — fetch the in-memory order created by `verify`

## Payments (Paystack)

Set `PAYSTACK_SECRET_KEY` in `.env`. Amounts you send to `/payments/init` are
in your currency's base unit (e.g. Naira), converted to kobo internally —
callers never do that math. `verify` is the single source of truth for
whether an order gets created; the client's callback alone is never enough.

## Price comparison ("get online shops and compare prices")

`src/services/priceService.js` is pluggable:

- `PRICE_PROVIDER=mock` (default) — deterministic, offline, no key needed.
  Returns 3-5 offers across Amazon/Walmart/Target/Best Buy/eBay/Newegg with
  price, shipping, total, and ETA — same shape either way.
- `PRICE_PROVIDER=serpapi` + `SERPAPI_KEY=...` — real Google Shopping
  results via SerpAPI. Falls back to mock automatically if the key is
  missing or the call fails, so it never hard-fails mid-demo.

Swap in a different real provider (Rainforest, a retailer's own API, etc.)
by adding a function next to `serpApiSearch` and branching on
`PRICE_PROVIDER` in `searchOffers()` — nothing else needs to change.

## Matching the Redtail frontend

Point the app's `API_BASE_URL` at this server and flip `USE_MOCKS = false`
in `src/services/apiClient.ts`. `chatService.ts` already expects
`POST /chat/threads/:id/messages` — same contract used here, just mounted
under `/api/v1`. The `offers` array in the chat response maps directly to
`ProductOffer[]`.

## Not included (intentionally, for tomorrow's demo)

- Auth (no login, no JWT — every request is treated as the same anonymous user)
- Database (chat threads live in memory and reset on server restart)
- Orders, addresses, payments, KYC, agent dashboard
- Docker

These are the "known gaps" — straightforward to layer on later using the
same patterns as the reference ShopBot backend (Postgres/Prisma, JWT auth,
Paystack, order state machine), but out of scope for getting the AI
endpoint working tonight.
